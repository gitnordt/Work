var royals = {"prince" : {"name": "Prince Nigel", "home": "denwillow_palace", "speed": 6000}, 
			  "king" : {"name": "King Edward", "home" : "bagore_palace", "speed": 4500, 
						"routes":{
							0:["altendorf_court", "altendorf_border_station"],
							1:["altendorf_border_station", "tikrit_bank", "tikrit_cathedral"],
							2:["sturmfeste_bank", "fabric_market", "tikrit_cathedral"],
							3:["altendorf_court", "tikrit_bank", "food_market"],
							4:["altendorf_border_station", "school_of_roggenburg"]
						}}, 
			  "duke" : {"name": "Duke Roderick", "home": "home_of_roderick", "speed": 2000,
						"routes":{
							0:["altendorf_border_station", "food_market"],
							1:["sturmfeste_bank", "kireet_cathedral", "denwillow_palace"],
							2:["altendorf_border_station", "tikrit_bank", "tikrit_cathedral"],
							3:["school_of_roggenburg", "sturmfeste_bank", "the_chateau"],
							4:["sturmfeste_bank", "fabric_market"],
							5:["school_of_roggenburg", "tikrit_cathedral", "food_market"]
						}}, 
			  "duchess" : {"name": "Duchess Madelyn", "home": "home_of_madelyn", "speed": 4000,
						"routes":{
							0:["bagore_palace", "altendorf_court"],
							1:["school_of_roggenburg", "school_of_roggenburg",  "home_of_roderick"],
							2:["tikrit_bank", "tikrit_cathedral", "food_market"],
							3:["school_of_roggenburg", "sturmfeste_bank", "the_chateau"],
							4:["sturmfeste_bank", "fabric_market"],
							5:["school_of_roggenburg", "tikrit_cathedral", "food_market"]
						}}, 
			  "countess" : {"name": "Countess Abigayle", "home": "home_of_abigayle", "speed": 5500,
						"routes":{
							0:["tikrit_bank", "tikrit_cathedral"],
							1:["school_of_roggenburg", "tikrit_cathedral"],
							2:["school_of_roggenburg", "sturmfeste_bank", "the_chateau"],
							3:["sturmfeste_bank", "fabric_market", "the_chateau"],
							4:["school_of_roggenburg", "food_market"]
						}},
			  "princess" : {"name": "Princess Ava", "home": ["bagore_palace", "home_of_madelyn", "home_of_abigayle", "home_of_roderick"], 
						"access" : ["tikrit_cathedral", "school_of_roggenburg", "bagore_palace", "altendorf_court", "home_of_madelyn", "home_of_abigayle", "home_of_roderick"]}
			 };
			
var places = ["Tikrit Cathedral", "Kireet Cathedral", "The Chateau", "School of Roggenburg", "School of Hoverland", 
			"Bagore Palace", "Denwillow Palace", "Food Market", "Farmer's Market", "Fabric Market", "Dress Tower", 
			"Altendorf Court", "Denwillow Court", "Altendorf Border Station", "Sudsmanor Border Station", "Tikrit Bank", 
			"Sturmfeste Bank", "Kireet Bank", "Duchess Madelyn's Home", "Countess Abigayle's Home", "Duke Roderick's Home"]

var countries = {"kireet" : {"cities" : ["sudsmanor", "denbrook", "denwillow", "hoverland"],
							"borders" : ["kireet_border", "tikrit_border"]}, 
				"tikrit" : {"cities" : ["bagore", "ferenbach", "dietzenfeld", "altendorf", "roggenburg"],
							"borders" : ["tikrit_border", "sturmfeste_border"]}, 
				"sturmfeste":{"cities" : ["wetterfort", "belseburg", "schensfeld"], 
							"borders" : ["sturmfeste_border", "kireet_border"]}
				};

function toCamelCase(str) {
	return str.replace(/(?:^|\s)\w/g, function(match) {
	  return match.toUpperCase();
	});
}

function isInArray(value, array) {
  //checks to see if a value exists in an array
  //console.log(value, array.indexOf(value), array.indexOf(value) > -1);
  return array.indexOf(value) > -1;
}