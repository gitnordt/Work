<?php

if (isset($_POST['name'])) {
	$nm = $_POST['name'];
	$co = $_POST['company'];
	$em = $_POST['email'];
	$sj = $_POST['subject'];
	$cm = $_POST['comment'];


	/*database connection and insert*/
	//$con = new mysqli('ema-corp.co', $username, $password, $dbname);
	//$con = mysqli_connect('localhost','peter','abc123','my_db');

	//if ($con->connect_error) { /*!$con ||*/ 
		//die("Connection failed: " . $con->connect_error);
	   // die('Connection failed: ' . mysqli_error($con));
	//}


	//$sql = "INSERT INTO 'comments' ('name', 'company', 'email', 'subject', 'comments', 'timestamp')
	//VALUES ('".$nm."', '".$co."', '".$em."', '".$sj."','".$cm."','".strftime("%F %T")."')";

	/*if ($conn->query($sql) === TRUE) {
		echo "New record created successfully";
	} else {
		echo "Error: " . $sql . "<br>" . $conn->error;
	}

	echo "";

	mysqli_close($con);*/

	/*email comments to admin*/
	$to = "pettysworld22@gmail.com";
	$subject = "Website Inquiry: " . $sj;
	$body = "Dear EMA, <br><br><bold>".$nm. "</bold> has submitted the following inquiry.
	<br><br>
	Name: ".$nm." <br>
	Company: ".$co." <br>
	Subject: ".$sj;
	
	if (!empty($cm)) {
		$body .= "<br><br>Comment: ".$cm." <br><hr>";
	}
	
	$headers = "From: ". $em ."\r\n";
	$headers .= "Content-type: text/html\r\n";
	echo $headers;
	if (mail($to, $subject, $body, $headers)) {
		echo("<p>Email successfully sent!</p>");
	} else {
		echo("<p>Email delivery failed.</p>");
	}

}
?>