function getUrlParams(param_name)
{
       var query = window.location.search.substring(1);
       var params = query.split("&");
       for (var i=0;i<params.length;i++) {
               var pair = params[i].split("=");
               if(pair[0] == param_name){return pair[1];}
       }
       return "";
}


function solrCall(url, params){
	$.ajax({
		url: url,
		async: false, 
		data: params,
		dataType: 'jsonp',
		jsonp: 'json.wrf',
		success: function(response){
			controlJSON(response);
		}
	});
}

var results = [];
function controlJSON(data){
	setTimeout(function(){
		results = data.response.docs;
	}, 200);
}

function returnResults(){
	//console.log(results);
	return results;
}

function ajaxCall(url, type, async, cache){
	var data;
	$.ajax({
		async: async, 
		cache: cache, 
		url: url,
		dataType: type,
		dataFilter: function(data) {
			var response; 
			if (type === 'json')
              return JSON.stringify(JSON.parse(data));
			else
			 return response = data;
		},
		success: function(response){
			data = response;
		}
	});
	return data;
}

function getOfficeDetails(office){
	var office_details = ajaxCall('01-DARPA-'+ office + '.json', 'json', false, true);
	return office_details;
}