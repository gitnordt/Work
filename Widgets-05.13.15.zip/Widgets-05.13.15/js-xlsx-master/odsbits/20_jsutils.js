var has_buf = (typeof Buffer !== 'undefined');
