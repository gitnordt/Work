function getYourResults(ucount, win_arr){
	var results = win_arr.none;
	if(ucount > 21)
		results = win_arr.bust;
	else if(ucount == 21)
		results = win_arr.player;
	
	return results;
}

function getDealerResults(ucount, dcount, win_arr){
	var results = win_arr.none;
	if(dcount > 21)
		results = win_arr.bust;
	else if(dcount == 21 || ucount < dcount)
		results = win_arr.dealer;
	else if(dcount == ucount)
		results = win_arr.tie;
	else if(ucount > dcount)
		results = win_arr.player;
	
	return results;
}

function getResults(ucount, dcount, win_arr){
	var results = win_arr.none;
	if(ucount == dcount && ucount == 21)
		results = win_arr.tie;
	else if(ucount == 21)
		results = win_arr.player;
	else if(dcount == 21)
		results = win_arr.dealer;
	else if(dcount > 21 && ucount > 21)
		results = win_arr.both_bust;
	else if(dcount > 21 || ucount > 21)
		results = win_arr.bust;
		
	return results;
}

function calculateCardsInHand(hand, cards){
	var cardsum = 0, acecount = 0;
	
	for(var i=0;i<cards.length;i++){
		if(cards[i].rank != 'A')
			cardsum = parseInt(rankToValue(cards[i].rank, cardsum)) + cardsum;
		else
			acecount ++;
			
		if(hand)
			hand.append(cards[i].getHTML());
		
		if(i == cards.length - 1 && acecount > 0){
			for(var j=0; j<acecount; j++)
				cardsum = parseInt(rankToValue('A', cardsum)) + cardsum;
		}
	}
	
	return cardsum;
}

function calculateWins(winner, opponent, uwins, dwins){
	var additional_text = "";
	
	if(winner == "opponent"){
		if(opponent.winner == "dealer")
			dwins ++;
		else if(opponent.winner == "player")
			uwins ++;
		
		additional_text = opponent.subject;
	}
	else if(winner == "player"){
		uwins ++;
	}
	else if(winner == "dealer"){
		dwins ++;
	}
	else if(winner == "both"){
		uwins ++;
		dwins ++;
	}
	
	return [uwins, dwins, additional_text];
}

//capitalize the first letter of the player's name
var toCamelCase = function(str) {
	return str.replace(/(?:^|\s)\w/g, function(match) {
	  return match.toUpperCase();
	});
}

var getCardValue = function(rank){
	var value = !isNaN(rank) ? rank : (rank == "K" || rank == "Q" || rank == "J") ? 10 : 0;
	return value;
}

var getAceValue = function(count){
	var value = 11;
	if(count + value > 21)
		value = 1;
	
	return value;
}

//calculate the value of a card
var rankToValue = function(rank, count){
	var value = 0;
	if(rank == "A")
		value = getAceValue(count);
	else
		value = getCardValue(rank);
	
	return value;
}

var lowDraw = function(count){
	if(count < 17)
		return true;
	else 
		return false;

}

var showError = function(msg){
	$('#game_status').flash_message({
		text: msg,
		how: 'append'
	});
}

var timer;

//toggle code for blinking card draw button
function blinkingButton(){
	if($("#shuffleDeal").hasClass("highlight-button"))
		$("#shuffleDeal").removeClass("highlight-button");
	else
		$("#shuffleDeal").addClass("highlight-button");
}

function startBlinkingButton(){
	timer = setInterval(blinkingButton, 2000);
	blinkingButton();
}

function stopBlinkingButton(){
	clearInterval(timer);
	$("#shuffleDeal").removeClass("highlight-button");
}

//message popup function to display the status of the game
$.fn.flash_message = function(options){
  options = $.extend({
	text: 'Done',
	time: 1500,
	how: 'before',
	class_name: ''
  }, options);
  
  return $(this).each(function() {
	if( $(this).parent().find('.flash_message').get(0) )
	  return;
	
	var message = $('<span/>', {
	  'class': 'flash_message ' + options.class_name,
	  text: options.text
	}).hide().fadeIn('fast');
	
	$(this)[options.how](message);
	
	message.delay(options.time).fadeOut('normal', function() {
	  $(this).remove();
	});
	
  });
};
