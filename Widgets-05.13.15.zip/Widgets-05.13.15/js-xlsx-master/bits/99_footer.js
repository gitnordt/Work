})(typeof exports !== 'undefined' ? exports : XLSX);
