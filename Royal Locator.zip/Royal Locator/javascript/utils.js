
var royals = ["Prince Nigel", "King Edward", "Princess Ava", "Duchess Madelyn", "Countess Abigayle", "Duke Roderick"];

var places = ["Tikrit Cathedral", "The Chateau", "School of Roggenburg", "Bagore Palace", 
			"Denwillow Palace", "Food Market","Fabric Market", "Court", "Border Station", 
			"Bank", "Duchess Madelyn's Home", "Countess Abigayle's Home", "Duke Roderick's Home"]

var countries = {"kireet" : [{"cities" : ["sudsmanor", "denbrook", "denwillow", "hoverland"]}, {"borders" : ["kireet_border", "tikrit_border"]}], 
			"tikrit" : [{"cities" : ["bagore", "ferenbach", "dietzenfeld", "altendorf", "roggenburg"]}, {"borders" : ["tikrit_border", "sturmfeste_border"]}], 
			"sturmfeste":[{"cities" : ["wetterfort", "belseburg", "schensfeld"]}, {"borders" : ["sturmfeste_border", "kireet_border"]}]};


function toCamelCase(str) {
	return str.replace(/(?:^|\s)\w/g, function(match) {
	  return match.toUpperCase();
	});
}