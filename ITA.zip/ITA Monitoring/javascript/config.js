
var url_origin = window.location.origin;
//change url to the original newserver if testing from localhost
if(url_origin.indexOf("localhost") > -1) 
	//url_origin = 'http://192.255.42.169'; //demo
	url_origin = 'http://192.255.33.43'; //dev

	
var overall_status = url_origin + ":8080/itacnd/status/overall"; //q=test&sort=id+asc&wt+json&indent=true
var system_status = url_origin + ":8080/itacnd/status/system"; //backend JAVA request
var control_info = url_origin + ":8080/itacnd/nist80053"; //backend JAVA request
var max_records = 100; //maximum number of records retrieved before user gets a warning

function getSystems() {
	return overall_status;

}

function getSystemControls(){
	return system_status;
}

function getControlInfo(){
	return control_info;
}

function getMaxRecords() {
	return max_records;
}

function getOriginURL() {
	return url_origin;
}

