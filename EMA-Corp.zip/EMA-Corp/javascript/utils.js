var url_origin = window.location.origin + "/EMA-Corp";
var url_complete = window.location.href;

var header = 	'<div id="logo">'
	header += 		'<a href="#"><img src="' + url_origin + '/images/ema.png" alt="EMA"></a>'
	header += 		'<h1>CORPORATION</h1>'
	header += 		'<p>Consulting and Services</p>'
	header += 	'</div>'
	header += 	'<div id="center">'
	header += 		'<div id="menu">'
	header += 			'<nav>'
	header += 				'<ul>'
	header += 				'<li><a href="' + url_origin + '/#">HOME</a></li>'
	header += 				'<li><a href="' + url_origin + '/about">ABOUT</a></li>'
	header += 				'<li><a href="' + url_origin + '/capabilities">CAPABILITIES</a></li>'
	header += 				'<li><a href="' + url_origin + '/values">VALUES</a></li>'
	header += 				'<li><a href="' + url_origin + '/contact">CONTACT</a></li>'
	header += 				'</ul>'
	header += 			'</nav>'
	header += 		'</div>'
	header += 	'</div>'
	header += 	'<div id="share"></div>';
		
var footer = '<p>Copyright EMA Corporation&nbsp;&nbsp;|&nbsp;&nbsp;Design by Pettysworld Promotions LLC</p>';
