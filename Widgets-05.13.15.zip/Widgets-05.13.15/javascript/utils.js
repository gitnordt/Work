﻿var monthNames = {"short" : [ "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" ],
				  "full" : [ "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" ]};
var dayNames = [ "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" ];

Array.prototype.contains = function(v) {
	for(var i = 0; i < this.length; i++) {
		if(this[i] === v) return true;
	}
	return false;
};

Array.prototype.unique = function() {
	var arr = [];
	for(var i = 0; i < this.length; i++) {
		if(!arr.contains(this[i])) {
			arr.push(this[i]);
		}
	}
	return arr; 
};

String.prototype.trim = function(){
	return this.replace(/^\s+|\s+$/g,'');
}

function sortByProperty(property){
	//sorts json array by a given property name
	
	return function (a,b){
		var sortStatus = 0;

		if(a[property] instanceof Date){
			if(a[property] < b[property])
				sortStatus = -1;
			else if (a[property] > b[property])
				sortStatus = 1;
		}
		else if(typeof a[property] == 'number' && a[property]%1 == 0){
			if(parseInt(a[property]) < parseInt(b[property]))
				sortStatus = -1;
			else if (parseInt(a[property]) > parseInt(b[property]))
				sortStatus = 1;
		}
		else if(typeof a[property] == 'number' && !!(a[property]%1)){
			if(parseFloat(a[property]) < parseFloat(b[property]))
				sortStatus = -1;
			else if (parseFloat(a[property]) > parseFloat(b[property]))
				sortStatus = 1;
		}
		else{
			if(a[property].toLowerCase().trim() < b[property].toLowerCase().trim())
				sortStatus = - 1;
			else if (a[property].toLowerCase().trim() > b[property].toLowerCase().trim())
				sortStatus = 1
		}
		
		return sortStatus;
	};
}


function isIEBrowser(){
	var userAgentVar = navigator.userAgent;
	var IE = false;

	if (userAgentVar.indexOf("MSIE") != "-1")
		IE = true;
		
	return IE;

}

function in_array(needle, haystack, argStrict) {
  var key = '',
    strict = !! argStrict;

  //we prevent the double check (strict && arr[key] === ndl) || (!strict && arr[key] == ndl)
  //in just one for, in order to improve the performance 
  if (strict) {
    for (key in haystack) {
      if (haystack[key] === needle) {
        return true;
      }
    }
  } else {
    for (key in haystack) {
      if (haystack[key] == needle) {
        return true;
      }
    }
  }

  return false;
}

function objectLength(obj){
	var n = 0;
	for(var o in obj) n++;
	
	return n;
}

function objectReverseSort(obj){
	var indices = [];
	for(var o in obj)
		indices.push(obj[o]);

	indices.reverse();

	var new_object = {};
	for (var i = 0; i < indices.length; i++){
		var curr_index = indices[i];
		new_object[curr_index.label] = curr_index;
	}
	
	return new_object;
}

function objectPropertySort(obj, property){
	var indices = [];

	for(var o in obj){
		var index = [];
		var curr_obj = obj[o];
		for (var c in curr_obj)
			index[c] = curr_obj[c];
		indices.push(index);
	}
	
	indices.sort(sortByProperty(property));
	
	if(property == "total")
		indices.reverse();
	var new_object = {};
	for (var i = 0; i < indices.length; i++){
		var base_object = {};
		var curr_obj = indices[i];
		for (var k in curr_obj)
			base_object[k] = curr_obj[k];
		new_object[base_object.label] = base_object;	
	}
	
	return new_object;
}

function checkLocalStorage(){
	
	var haslocalStorage = false;
	if (typeof(localStorage) == "undefined" ){
		if(!isIEBrowser)
			console.log('Your browser does not support HTML5 localStorage. Try upgrading.');
		haslocalStorage = false;
	}
	else{
		try {
			  localStorage.setItem("test", "Hello World!"); //saves to the database, "key", "value"
			  localStorage.removeItem("test"); 
			  haslocalStorage = true;
		} 
		catch(e){
			if (e == QUOTA_EXCEEDED_ERR && !isIEBrowser) {
				console.log('Local Storage quota exceeded!'); //data wasn’t successfully saved due to quota exceed so throw an error
			}
		   
			haslocalStorage = false; 
		}
	}
	
	return haslocalStorage;

}

function validateDate(string_date, hasday, fullyear){
	var date = new Date(string_date);
	var new_date = null;

	if(string_date){
		var month = date.getMonth()+1;
			month = month.toString().length < 2 ? "0" + month.toString() + "/" : month.toString() + "/" ;
		
		var day = "";
		if(hasday != false){
			day = date.getDate().toString().length < 2 ? "0" + date.getDate() + "/" : + date.getDate() + "/";
		}else
			day = "";

		if (date.getFullYear() < 2000) {
			var year = date.getFullYear()+100;
			date.setFullYear(year);
		}

		if(fullyear == true)
			new_date = month + day + date.getFullYear();
		else
			new_date = month + day + date.getYear().toString().slice(-2);

	}
	
	return new_date;
}