function displayGraph() {
	var margin = {top: 20, right: 95, bottom: 10, left: 125},
		width = 970 - margin.left - margin.right,
		height = 600,
		maxSize = 250e9,
		maxRadius = 12,
		padding = 1.5, 
		clusters = 8, // number of distinct clusters
		tickExtension = 20; // extend grid lines beyond scale range
		
	var formatPercent = d3.format(".0%"),
		formatTenthPercent = d3.format(".1%"),
		formatNumber = d3.format(",.3s"),
		formatDollars = function(d) { return (d < 0 ? "-" : "") + "$" + formatNumber(Math.abs(d)).replace(/G$/, "B"); };

	var nameAll = "ESS Division";
	
	var color = d3.scale.category10()
		.domain(d3.range(clusters));

	var x = d3.scale.ordinal()
		.domain(d3.range(clusters))
		.rangeBands([0, width]);

	var y = d3.scale.ordinal();
	
	var y0 = d3.scale.ordinal()
		.domain([nameAll])
		.range([150]);

	var r = d3.scale.sqrt()
		.domain([0, 1e9])
		.range([0, 1]);
		
	//color key at bottom of main page
	var z = d3.scale.threshold()
		.domain([0, .1, .2, .3, .4, .5, .6, .7])
		.range(["#b35806", "#f1a340", "#fee0b6", "#d8daeb", "#998ec3", "#542788", "#483C32", "#800080"].reverse());

			
	var xAxis = d3.svg.axis()
		.scale(x)
		.orient("top")
		.ticks(7)
		.tickFormat(function(d) {return formatPercent(d / 10)});

	var yAxis = d3.svg.axis()
		.scale(y)
		.orient("left")
		.tickSize(-width + 60 - tickExtension * 2, 0)
		.tickPadding(4);	
	
	var svg = d3.select(".g-graphic").append("svg")
		.attr("height", 220 + margin.top + margin.bottom)
		.attr("width", width + margin.left + margin.right)
	.append("g")
		.attr("transform", "translate(" + margin.left + "," + margin.top + ")");
	
	d3.select(".g-graphic").append("svg")
		.style("margin-top", "20px")
		.attr("height", 80)
		.attr("width", width + margin.left + margin.right)
	  .append("g")
		.attr("transform", "translate(" + margin.left + "," + margin.top + ")")
		.call(renderChartKey);
		
	var gx = svg.append("g")
		.attr("class", "g-x g-axis")
		.call(xAxis);

	//gets the last tick title on the system scores
	var tickLast = gx.selectAll(".g-x .tick:last-of-type");

	tickLast.select("text")
		.text(function() { return "\u2265 " + this.textContent; });

	tickLast.select(function() { return this.parentNode.appendChild(this.cloneNode(true)); })
		.attr("transform", "translate(" + width + ",0)")
	  .select("text")
		.text("N.A.");

	var titleX = gx.append("text")
		.attr("class", "g-title")
		.attr("y", -9)
		.style("text-anchor", "end");

	titleX.append("tspan")
		.attr("x", -20)
		.style("font-weight", "bold")
		.text("System Scores");

	titleX.append("tspan")
		.attr("x", -20)
		.attr("dy", "1em")
		.text("Good \u2265 70%");
		
	var sectors, controls, sector, sectorCompany;
	d3.tsv("/ITA Monitoring/data/ita_systems.tsv", type, function(error, nodes) {
		//console.log(nodes);
		sectors = d3.nest()
		  .key(function(d) { return d.sector; })
		  .entries(nodes);

		//the rate is the percentage of taxes paid based on earnings, if earned 100 and paid 20 in taxes....rate = 20%
		//this is displayed on the marker in the center of the graph
		var overallRate = rate(d3.sum(nodes, taxes), d3.sum(nodes, earnings));

		// Compute the overall rate by sector.
		// Shown on the marker on the breakdown page
		sectors.forEach(function(d) {
		d.rate = rate(d3.sum(d.values, taxes), d3.sum(d.values, earnings));
		});

		// Sort sectors by ascending overall rate.
		sectors.sort(function(a, b) {
		return a.rate - b.rate;
		});
		  
		
		// Compute the rate for each company.
		//effective tax rate shown in the dialog box of each company
		nodes.forEach(function(d) {
			d.rate = rate(d.taxes, d.earnings);
			d.color = isNaN(d.rate) ? '#C2BEBD' : color(z(d.rate)); 
		});
		
		// Sort sectors by ascending overall rate.
		nodes.sort(function(a, b) {
			return a.rate - b.rate;
		});
		
			  	
		controls = d3.nest()
		  .key(function(d) { console.log(d.rate, d.color); return d.color; })
		  .entries(nodes);
		  
		controls.forEach(controlForce); 
		 
		
		height = 120 * sectors.length;
		
		y.domain(sectors.map(function(d) { return d.key; }))
		  .rangePoints([10, height], 1); 

		
		svg.append("g")
		  .attr("class", "g-y g-axis g-y-axis-sector")
		  .attr("transform", "translate(-" + tickExtension + ",0)")
		  .call(yAxis.scale(y))
		  .call(yAxisWrap)
		  .style("stroke-opacity", 0)
		  .style("fill-opacity", 0)
		.selectAll(".tick text,.tick tspan")
		  .attr("x", -95)
		  .style("text-anchor", "start");

		svg.append("g")
		  .attr("class", "g-y g-axis g-y-axis-overall")
		  .attr("transform", "translate(-" + tickExtension + ",0)")
		  .call(yAxis.scale(y0))
		  .call(yAxisWrap);
		

	});
	
	function renderChartKey(g) {
	  var formatPercent = d3.format(".0%"),
		  formatNumber = d3.format(".0f");

	  // A position encoding for the key only.
	  var x = d3.scale.linear()
		  .domain([0, .7])
		  .range([0, 240]);

	  var xAxis = d3.svg.axis()
		  .scale(x)
		  .orient("bottom")
		  .tickSize(13)
		  .tickValues(z.domain())
		  .tickFormat(function(d) { return d === .7 ? formatPercent(d) : formatNumber(100 * d); });

	  g.append("text")
		  .attr("x", 24)
		  .attr("y", 4)
		  .style("text-anchor", "end")
		  .style("font", "bold 9px sans-serif")
		  .text("CHART KEY");

	  //color chart at bottom of the page
	  var gColor = g.append("g")
		  .attr("class", "g-key-color")
		  .attr("transform", "translate(170,-7)");

	  gColor.selectAll("rect")
		  .data(z.range().map(function(d, i) {
			return {
			  x0: i ? x(z.domain()[i - 1]) : x.range()[0],
			  x1: i < 7 ? x(z.domain()[i]) : x.range()[1],
			  z: d
			};
		  }))
		.enter().append("rect")
		  .attr("height", 8)
		  .attr("x", function(d) { return d.x0; })
		  .attr("y", 5)
		  .attr("width", function(d) { return d.x1 - d.x0; })
		  .style("fill", function(d) { return color(d.z); });

	  gColor.call(xAxis);

	  //chart key and color text
	  var gColorText = g.append("text")
		  .attr("x", 160)
		  .attr("y", 5)
		  .style("text-anchor", "end");

	  gColorText.append("tspan")
		  .style("font-weight", "bold")
		  .text("Color");

	  gColorText.append("tspan")
		  .style("fill", "#777")
		  .text(" shows scores");

	  //chart key end of line length
	  var gSize = g.append("g")
		  .attr("class", "g-key-size")
		  .attr("transform", "translate(590,-7)");

	  //circle sizes and text in chart key
	  var gSizeInstance = gSize.selectAll("g")
		  .data([{"risk":"low", "size":10e9}, {"risk":"medium", "size":90e9}, {"risk":"high", "size":maxSize}])
		.enter().append("g")
		  .attr("class", "g-sector");
		
	  gSizeInstance.append("circle")
		  .style("fill", "#c2bebd")
		  .attr("r", function(d) { return r(d.size);});

	  gSizeInstance.append("text")
		  .attr("x", function(d) {return r(d.size) + 4; })
		  .attr("dy", ".35em")
		  .text(function(d) { return d.risk;});

	  var gSizeX = 0;

	  gSizeInstance.attr("transform", function() {
		var t = "translate(" + gSizeX + ",10)";
		gSizeX += this.getBBox().width + 25;
		return t;
	  });

	  var gSizeText = g.append("text")
		  .attr("x", 580)
		  .attr("y", 6.5)
		  .style("text-anchor", "end");

	  gSizeText.append("tspan")
		  .style("font-weight", "bold")
		  .text("Size");

	  gSizeText.append("tspan")
		  .style("fill", "#777")
		  .text(" shows risk level");
	}
	
	function controlForce(entry, i) {
	  var nodes = entry.values;
	 console.log(entry);
	  var force = d3.layout.force()
		  .nodes(nodes) //should add px and py
		  .size([x.rangeBand(), height])
		  .gravity(.2)
		  .charge(0)
		  .on("tick", controlTick)
		  .start();

	  var controlCircles = svg.append("g")
		  .attr("transform", "translate(" + x(i) + ", -150)")
		.selectAll("circle")
		  .data(nodes)
		.enter().append("circle")
		  .attr("r", function(d) {d.radius = r(d.capitalization) + 8; return d.radius;}) //changed
		  .style("fill", function(d) { return d.color});

	  function controlTick(e) {
			controlCircles
			.each(collide(.5, nodes))
			.attr("cx", function(d) { return d.x; })
			.attr("cy", function(d) { return d.y; });
	  }
	}
	
	function sectorForce(entry, i) {
	  var nodes = entry.values;
	  console.log(entry);
	  var force = d3.layout.force()
		  .nodes(nodes) //should add px and py
		  .size([x.rangeBand(), height])
		  .gravity(.2)
		  .charge(0)
		  .on("tick", sectorTick)
		  .start();

	  var sectorCircles = svg.append("g")
	      .attr("class", "g-sector")
		  .attr("transform", "translate(" + x(i) + ")")
		.selectAll("circle")
		  .data(nodes)
		.enter().append("circle")
		  .attr("r", function(d) {d.radius = r(d.capitalization) + 8; return d.radius;}) //changed
		  .style("fill", function(d) { return isNaN(d.rate) ? '#C2BEBD' : color(z(d.rate)); })

	  function sectorTick(e) {
			sectorCircles
			.each(collide(.5, nodes))
			.attr("cx", function(d) { return d.x; })
			.attr("cy", function(d) { return d.y; });
	  }
	}
	
	

	// Resolves collisions between d and all other circles.
	function collide(alpha, nodes) {
		var quadtree = d3.geom.quadtree(nodes);
		return function(d) {
		  var r = d.radius + maxRadius + padding,
			  nx1 = d.x - r,
			  nx2 = d.x + r,
			  ny1 = d.y - r,
			  ny2 = d.y + r;
		  quadtree.visit(function(quad, x1, y1, x2, y2) {
			if (quad.point && (quad.point !== d)) {
			  var x = d.x - quad.point.x,
				  y = d.y - quad.point.y,
				  l = Math.sqrt(x * x + y * y),
				  r = d.radius + quad.point.radius + padding;
			  if (l < r) {
				l = (l - r) / l * alpha;
				d.x -= x *= l;
				d.y -= y *= l;
				quad.point.x += x;
				quad.point.y += y;
			  }
			}
			return x1 > nx2 || x2 < nx1 || y1 > ny2 || y2 < ny1;
		  });
		};
	}	
	
	function mouseover(d) {
		sectorCompany.filter(function(c) { return c === d; }).classed("g-active", true);

		var dx, dy;
		if (currentView === "overall") dx = d.cx, dy = d.cy + y0(nameAll);
		else dx = d.x, dy = d.y + y(d.sector);
		dy -= 19, dx += 50; // margin fudge factors

		tip.style("display", null)
			.style("top", (dy - r(d.capitalization)) + "px")
			.style("left", dx + "px");

		tip.select(".g-tip-title")
			.text(d.alias || d.name);

		tipMetric.select(".g-tip-metric-value").text(function(name) {
		  switch (name) {
			case "rate": return isNaN(d.rate) ? "N.A." : formatPercent(d.rate);
			case "taxes": return formatDollars(d.taxes);
			case "earnings": return formatDollars(d.earnings);
		  }
		});
	}

	function mouseout() {
		tip.style("display", "none");
		sectorCompany.filter(".g-active").classed("g-active", false);
	}		
	
	function yAxisWrap(g) {
	  g.selectAll(".tick text")
		.filter(function(d) { return /[ ]/.test(d) && this.getComputedTextLength() > margin.left - tickExtension - 10; })
		  .attr("dy", null)
		  .each(function(d) {
			d3.select(this).text(null).selectAll("tspan")
				.data(d.split(" "))
			  .enter().append("tspan")
				.attr("x", this.getAttribute("x"))
				.attr("dy", function(d, i) { return (i * 1.35 - .35) + "em"; })
				.text(function(d) { return d; });
		  });
	}	
	
	function taxes(d) {
	  return d.taxes;
	}

	function earnings(d) {
	  return d.earnings;
	}	
	
	function rate(taxes, earnings) {
	  return earnings <= 0 ? NaN : taxes / earnings;
	}
	
	function type(d) {
	  d.taxes *= 1e6;
	  d.earnings *= 1e6;
	  d.capitalization *= 1e6;
	  return d;
	}
	
	var sectorNoteByName = {
	  "Utilities": "Utilities benefited from the 2009 stimulus bill, which included tax breaks for companies that make capital-intensive investments, like power plants.",
	  "Information technology": "Technology companies can often move operations overseas for accounting purposes. And younger firms tend to have recent losses, holding down the sector&rsquo;s overall rate.",
	  "Industrials": "As with the corporate sector, large industrial companies &mdash; like <b>Boeing</b>, <b>Caterpillar</b>, <b>General Electric</b> and <b>Honeywell</b> &mdash; pay lower taxes on average than small companies.",
	  "Telecom": "<b>Verizon</b> had a much lower effective tax rate than its rival <b>AT&T</b>, despite having similar profits over the six-year period.",
	  "Health care": "Within health care, managed care companies pay relatively higher tax rates, and makers of equipment, supplies and technology pay relatively lower rates.",
	  "Pharma": "Tax breaks for research and the ability to locate operations in low-tax countries have helped pharmaceutical and biotech companies to pay low taxes.",
	  "Consumer products": "Movie studios and packaged-food company pay more than 30 percent, on average. Soft-drink companies pay only 19 percent, and restaurant companies, 25 percent.",
	  "Materials": "The materials industry (chemicals, minerals, etc.) exemplifies a point often made by tax experts: within industries, tax rates vary greatly, in ways that often evade simple explanation.",
	  "Financials": "As financial firms have recovered from the crisis, some have paid relatively high tax rates.",
	  "Retailers": "Brick-and-mortar retailers, like <b>Bed Bath & Beyond</b> and <b>Home Depot</b>, tend to pay high tax rates. Online retailers, like <b>Amazon</b>, face low rates.",
	  "Energy": "Large oil companies typically pay high rates, but some economists argue that the high rates do not cover the pollution costs imposed on society.",
	  "Insurance": "Many insurers pay lower-than-average rates. But <b>A.I.G.</b> &mdash; which had an $83 billion loss while paying $8 billion in taxes &mdash; drives the sector&rsquo;s average up.",
	  "Pentagon": "The Pentagon...",
	  "HQDA": "The HQDA...",
	  "Mark Center": "The Mark Center...",
	  "Army": "The Army...",
	  "Service": "The Services...",
	  "Security": "The Security...",  
	  "Coral": "The Coral...",  
	  "Research": "The Research...",
	};
}