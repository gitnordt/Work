<?php

<?php

if (isset($_POST['name'])) {
	$nm = $_POST['name'];
	$co = $_POST['company'];
	$em = $_POST['email'];
	$sj = $_POST['subject'];
	$cm = $_POST['comment'];


	/*database connection and insert*/
	$servername = "servername";
	$username = "ema_admin";
	$password = "your_password";
	$dbname = "your_db";

	/*database connection and insert*/
	$con = mysql_connect($servername, $username, $password);
    
	if (!$con){
	    die('Connection failed: ' . mysql_connect_error($con));
	}
	 
	mysql_select_db($dbname);
	$sql = "INSERT INTO contact_submissions (full_nm, company_nm, email, subject, comment) VALUES ('".$nm."', '".$co."', '".$em."', '".$sj."','".$cm."')";

	if (mysql_query( $sql, $con)) {
		echo "New record successfully created!\r\n";
	} else {
		echo "Error: " . $sql . "\r\n;" . mysql_error($con) . "\r\n";
	}
	
    mysql_close($con);

	/*email comments to admin*/
	$to = "test@test.com";
	$subject = "Website Inquiry: " . $sj;
	$body = "Dear Company, <br><br><span style='font-weight:bold;'>".$nm. "</span> has submitted the following inquiry.
	<br><br>
	Name: ".$nm." <br>
	Company: ".$co." <br><br>
	Subject: ".$sj;
	
	if (!empty($cm)) {
		$body .= "<br><br>Comment: ".$cm." <br>";
	}
        $body .=	"<hr>";

	$headers = "From: ". $em ."\r\n";
	$headers .= "Content-type: text/html\r\n";

	if (mail($to, $subject, $body, $headers)) {
		echo "Email successfully sent!";
	} else {
		echo "Email delivery failed";
	}
}
?>