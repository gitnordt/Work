playingCards.defaults.jokers = 0; //do not include jokers
var cardDeck = $("#cardDeck").playingCards();
var win_arr = {"none":{"winner": "", "subject":""}, "tie":{"winner": "both", "subject":"It's a tie!"}, "player":{"winner": "player", "subject":"You win!"}, 
				"dealer":{"winner": "dealer", "subject":"Dealer wins!"}, "bust":{"winner": "opponent", "subject":"It's a bust!"}, 
				"both_bust":{"winner": "dealer", "subject":"It's a bust! Dealer wins!"}};
var player = [], dealer = [];

/******************************************************************************************************************/
//Only one deck will be used per game, The deck should be shuffled before each game
//checks 3 card positions in case 1 card may have ended up in the same position of the deck. Rare but possible case.
QUnit.test( "Shuffle Deck", function( assert ) {
	var positions = [3, 24, 46]; 
	var shuffled = false, before_shuffle = null, after_shuffle = null, idx=0;
	for(var i=0; i<positions.length; i++){
		before_shuffle = cardDeck.cards[positions[i]];
		cardDeck.shuffle(); //<--testing
		after_shuffle = cardDeck.cards[positions[i]];

		if(before_shuffle.rank != after_shuffle.rank || before_shuffle.suit != after_shuffle.suit ){
			idx = positions[i];
			break;
		}
	}
	
	var msg = "Passed Shuffle : Position " + idx + " checked. " + before_shuffle.rankString + " of " + before_shuffle.suitString + " before shuffle , "; 
	msg += after_shuffle.rankString + " of " + after_shuffle.suitString + " after shuffle." ;
	assert.notEqual(before_shuffle, after_shuffle, msg); 
});	

/******************************************************************************************************************/
//All cards count as their face value, except A which can be 1 or 11 and J, Q, K all count as 10
QUnit.test( "Pip Card Value", function( assert ) {
	var my_num = 5;
	var pip_value = getCardValue(my_num); //<--testing
	assert.equal( my_num, pip_value, "Passed Pip Card Match : " + my_num + " = " + pip_value + ".");
});

QUnit.test( "Face Card Value", function( assert ) {
	var my_face = "Q";
	var face_value = getCardValue(my_face); //<--testing
    assert.equal( face_value, 10, "Passed Face Card Conversion : " + my_face + " = 10.");
  
});		

QUnit.test( "Ace Card Value", function( assert ) {
	var ace_value_high = getAceValue(8); //<--testing
	assert.equal( ace_value_high, 11, "Passed High Ace: card count = 8, Ace = " + ace_value_high + ".");
	
	var ace_value_low = getAceValue(19);
	assert.equal( ace_value_low, 1, "Passed Low Ace : card count = 19, Ace = " + ace_value_low + ".");
});	

/******************************************************************************************************************/
//There will be only 2 players – a "human" player and a dealer, The players are each dealt 2 cards to start the hand, 
//The player always takes their turn before the dealer			
QUnit.test( "2 Player, 2 Card Deal", function( assert ) {
	for(var i=0; i<4; i++){
		var c = cardDeck.draw(); //<--testing
		if(i%2 == 0){
			player[player.length] = c;
		}
		else{
			dealer[dealer.length] = c;
		}
	}	
	assert.equal( player.length, 2, "Passed :  Player has 2 cards." );
	assert.equal( dealer.length, 2, "Passed : Dealer has 2 cards." );
});	

/******************************************************************************************************************/
//The player can choose to hit or stand with any amount
QUnit.test( "Player Card Count : Hit, Stand, or 21", function( assert ) {
	var count = calculateCardsInHand("", player); //<--testing
	assert.ok( !isNaN(count), "Passed : Player Card Count = " + count + "." );
});	

//The dealer must hit if his cards total less than 17 and stand otherwise
QUnit.test( "Dealer hits if count < 17 and stands otherwise", function( assert ) {
	var count = calculateCardsInHand("", dealer);
	var msg = "";
	if(lowDraw(count)){ //<--testing
		msg = "Dealer hits.";
	}
	else
		msg = "Dealer stands.";
		
	assert.ok( !isNaN(count), "Passed : Dealer Card Count = " + count + ", " + msg );
});

/******************************************************************************************************************/
//If the player’s or dealer’s cards total over 21, they bust and their turn is over
QUnit.test( "One player has > 21", function( assert ) {
	var p_results = getYourResults(23, win_arr); //<--testing
	assert.equal( p_results.winner, "opponent", "Passed : Player busts with 23, Dealer wins!" );
	
	var d_results = getDealerResults(18, 24, win_arr); //<--testing
	assert.equal( d_results.winner, "opponent", "Passed : Dealer busts with 24, Player wins!" );
});

//If both players bust, the dealer wins
QUnit.test( "Both players have > 21", function( assert ) {
	var results = getResults(22, 24, win_arr); //<--testing
	assert.equal( results.winner, "dealer", "Passed : Player busts with 22 and Dealer busts with 24, Dealer wins!" );
});

//If either player has 21 with their first two cards, they win
QUnit.test( "One player has 21", function( assert ) {
	var p_results = getYourResults(21, win_arr); //<--testing
	assert.equal( p_results.winner, "player", "Passed : Player wins with 21!" );
	
	var d_results = getDealerResults(18, 21, win_arr); //<--testing
	assert.equal( d_results.winner, "dealer", "Passed : Dealer wins with 21!" );
});	

//If they both have 21 on their first two cards,it is a tie
QUnit.test( "Both players have 21", function( assert ) {
	var results = getResults(21, 21, win_arr); //<--testing
	assert.equal( results.winner, "both", "Passed : Both have 21! "  + results.subject + ".");
});	

//If both players have the same score, they tie
QUnit.test( "Tied Game", function( assert ) {
	var results = getDealerResults(18, 18, win_arr); //<--testing
	assert.equal( results.winner, "both", "Passed : Both have 18! " + results.subject + ".");
});						