
function getResults(){
	var response =
		$.ajax({
			url: getSystems(),
			data: 'wt=json',
			dataType: 'jsonp',
			jsonp: 'json.wrf',
			success: function(data){
				displayGraph(data);
			},
			error:function(jqXHR, textStatus, errorThrown){
				console.log(jqXHR.status);
				$('.g-notes').empty().append("<br><br><center><p><span>The server is misbehaving. Please contact your sysadmin.</span></p></center>");
			},
			fail: function (xmlHttpRequest, textStatus) {
				console.log(textStatus);
				$('.g-notes').empty().append("<br><br><center><p><span>The request to the server has failed. Please contact your sysadmin.</span></p></center>");
			}
		});
		
		return response;
}

function displayGraph(response) {
	var margin = {top: 20, right: 95, bottom: 10, left: 175},
		width = 1250 - margin.left - margin.right,
		height = 600,
		keyMaxSize = 450e9,
		maxRadius = 12,
		padding = 1.5, 
		clusters = 11,
		tickExtension = 10; // extend grid lines beyond scale range
		
	var formatPercent = d3.format(".0%"),
		formatTenthPercent = d3.format("%"),
		formatNumber = d3.format(",.3s"),
		formatDollars = function(d) { return (d < 0 ? "-" : "") + "$" + formatNumber(Math.abs(d)).replace(/G$/, "B"); };

	var nameAll = "ESS Division";
	
	//var color = d3.scale.category10()
	//	.domain(d3.range(clusters));
	
	var nodes = response.systemList;	
	var itaRate = null, essRate = null;
	var nodeCount = nodes.length;

	$.map(response.summarys, function(obj) {
		if(obj.name == "ITA Overall")
			itaRate = parseFloat(obj.successRate);
		else if(obj.name == "Enterprise Controls")
			essRate = parseFloat(obj.successRate);
	});
	
	$("#ita-overall-rate").html($("#ita-overall-rate").html() + formatTenthPercent(itaRate));
		
	var x = d3.scale.ordinal()
		.domain(d3.range(clusters))
		.rangeBands([0, width-60]); //percentage display

	var x0 = d3.scale.linear()
		.domain(d3.range(clusters))
		.rangeRound([0, width-144]) //circle placement based on width of graph
		.clamp(true)
		.nice();

	var y = d3.scale.ordinal();
	
	var y0 = d3.scale.ordinal()
		.domain([nameAll])
		.range([150]); //chart key display

	var r = d3.scale.sqrt()
		.domain([0, 1e9])
		.range([0, 1]);
	
	var r0 = d3.scale.sqrt()
		.domain(d3.range(clusters))
		.range([0, 1]);
		
	//color key at bottom of main page
	var z = d3.scale.threshold()
		.domain([0, .1, .2, .3, .4, .5, .6, .7, .8, .9, 1])
		.range(["#d62728", "#d62728", "#d62728", "#d62728", "#d62728", "#d62728", "#d62728", "#FF726F", "#7FE817", "#2ca02c", "#2ca02c","#2ca02c"]);

		
	var xAxis = d3.svg.axis()
			.scale(x)
			.orient("top")
			.ticks(clusters)
			.tickFormat(function(d) {return formatPercent(d / 10)});

	var yAxis = d3.svg.axis()
		.scale(y)
		.orient("left")
		.tickSize(-width + 60 - tickExtension, 0)
		.tickPadding(5);	
	
	var svg = d3.select(".g-graphic").append("svg") //graph svg
		.attr("height", 220 + margin.top + margin.bottom) 
		.attr("width", width + margin.left + margin.right)
	.append("g")
		.attr("transform", "translate(" + margin.left + "," + margin.top + ")");
	
	d3.select(".g-graphic").append("svg") //chart key svg
		.style("margin-top", "20px")
		.attr("height", 80)
		.attr("width", width + margin.left + margin.right) 
	  .append("g")
		.attr("transform", "translate(" + margin.left + "," + margin.top + ")")
		.call(renderChartKey);
		
	var gx = svg.append("g")
		.attr("class", "g-x g-axis")
		.call(xAxis);

	//gets the last tick title on the system scores
	var tickLast = gx.selectAll(".g-x .tick:last-of-type");

	tickLast.select("text")
		.text(function() { return this.textContent; });

	//var tick_x = width;
	tickLast.select(function() { return this.parentNode.appendChild(this.cloneNode(true)); })
		.attr("transform", "translate(" + width + ",0)")
	  .select("text")
		.text("N.A.");

	var titleX = gx.append("text")
		.attr("class", "g-title")
		.attr("y", -9)
		.style("text-anchor", "end");

	titleX.append("tspan")
		.attr("x", -20)
		.style("font-weight", "bold")
		.text("System Scores");

	titleX.append("tspan")
		.attr("x", -20)
		.attr("dy", "1em")
		.text("Good \u2265 70%");
		
	var systems, controls, new_nodes;
	var systemControl = [];
	
	var tip = d3.select(".g-tip");

	var tipMetric = tip.selectAll(".g-tip-metric")
	  .datum(function() { return this.getAttribute("data-name"); });  	
	
    /****************************************functions*******************************************/	

	function systemSetup() {
		var number_nodes = [], nonnum_nodes = [];
		nodes.forEach(function(d) {
			d.rate = parseFloat(d.successRate);
			d.color = z(d.rate);
			
			if(isNaN(d.rate))
				nonnum_nodes.push(d);
			else
				number_nodes.push(d);			
		});
		
		// Sort nodes by ascending overall rate.
		number_nodes.sort(function(a, b) {
			return a.rate - b.rate;
		});
		
		new_nodes = number_nodes;
		nonnum_nodes.forEach(function(d){ new_nodes.push(d); });

		controls = d3.nest()
		  .key(function(d) {return d.rate.toFixed(2);}) //fix
		  .entries(new_nodes);
		 
		systemControl = svg.append("g")
		  .attr("class", "g-controls");
 
		controls.forEach(controlForce);

		height = 120 * controls.length;
		
		y.domain(controls.map(function(d) { return d.key; }))
		  .rangePoints([0, height], 1); 

		svg.append("g")
		  .attr("class", "g-y g-axis g-y-axis-overall")
		  .attr("transform", "translate(-" + tickExtension + ",0)")
		  .call(yAxis.scale(y0))
		  .call(yAxisWrap);

		var cursor = parseInt(x0(essRate)); //overall cursor placement
		
		var overall = svg.append("g")
		  .attr("class", "g-overall g-overall-all")
		  .attr("transform", "translate(" + (cursor + 44) + "," + y0(nameAll) + ")");

		overall.append("line")
		  .attr("y1", -100)
		  .attr("y2", +100);

		var overallText = overall.append("text")
		  .attr("y", -106)
		  .style("font-weight", "bold");

		overallText.append("tspan")
		  .attr("x", 2)
		  .style("font-size", "13px")
		  .text(formatTenthPercent(essRate));

		overallText.append("tspan")
		  .attr("x", 0)
		  .attr("dy", "-14")
		  .style("font-size", "12px")
		  .text("ESS Overall");
		  
		var searchInput = d3.select(".g-search input")
		  .on("keyup", keyuped);

		var searchClear = d3.select(".g-search .g-search-clear")
		  .on("click", function() {
			searchInput.property("value", "").node().blur();
			search();
		  });
		  
		var tip = d3.select(".g-tip");	

		var tipMetric = tip.selectAll(".g-tip-metric")
		  .datum(function() { return this.getAttribute("data-name"); });

		setTimeout(function(){
			var last_move = null;
			systemControl.selectAll("circle").each(function(d,i){
				var current_x = $("#" + d.rate.toString().replace(".", ""))[0].attributes.transform.value.match(/\d+/)[0];
				var previous_circle = $('.g-controls circle')[i-1];
				
				if(previous_circle){
					var previous_r = previous_circle.attributes.r.value;
					var previous_cy = last_move != null ? last_move : previous_circle.attributes.cy.value;
					var previous_x = previous_circle.parentNode.attributes.transform.value.match(/\d+/)[0];
					last_move = null;

					if(d.y > (previous_cy - 140) && d.y < (parseFloat(previous_cy) + 140)
					  && current_x > (previous_x - 50) && current_x < (parseFloat(previous_x) + 50))
					{
						var set_y = parseFloat(previous_cy) - (parseInt(previous_r) + parseInt(d.radius) + 20);
						
						if(set_y < 210)
							set_y = 360;

						d.y = set_y;
						last_move = set_y;
						d3.select("#" + d.shortName.replace(" ", "__"))
							.transition().ease('linear').duration(400)
							.attr('cy', function(e) { return e.y; });	
					}
				}		
			});
		}, 1400);
	
	};
	
	systemSetup();
	
	function renderChartKey(g) {
	  var formatPercent = d3.format(".0%"),
		  formatNumber = d3.format(".0f");

	  // A position encoding for the key only.
	  var x = d3.scale.linear()
		  .domain([0, 1])
		  .range([0, 280]);

	  var xAxis = d3.svg.axis()
		  .scale(x)
		  .orient("bottom")
		  .tickSize(12)
		  .tickValues(z.domain())
		  .tickFormat(function(d) { return d === 1 ? formatPercent(d) : formatNumber(100 * d); });

	  g.append("text")
		  .attr("x", 24)
		  .attr("y", 4)
		  .style("text-anchor", "end")
		  .style("font", "bold 9px sans-serif")
		  .text("CHART KEY");

	  //color chart at bottom of the page
	  var gColor = g.append("g")
		  .attr("class", "g-key-color")
		  .attr("transform", "translate(170,-7)");

	  gColor.selectAll("rect")
		  .data(z.range().map(function(d, i) {
			return {
			  x0: i ? x(z.domain()[i - 1]) : x.range()[0],
			  x1: i < 11 ? x(z.domain()[i]) : x.range()[1],
			  z: d
			};
		  }))
		.enter().append("rect")
		  .attr("height", 8)
		  .attr("x", function(d) { return d.x0; })
		  .attr("y", 5)
		  .attr("width", function(d) { return d.x1 - d.x0; })
		  .style("fill", function(d) { return d.z;});

	  gColor.call(xAxis);

	  //chart key and color text
	  var gColorText = g.append("text")
		  .attr("x", 160)
		  .attr("y", 5)
		  .style("text-anchor", "end");

	  gColorText.append("tspan")
		  .style("font-weight", "bold")
		  .text("Color");

	  gColorText.append("tspan")
		  .style("fill", "#777")
		  .text(" shows scores");

	  //chart key end of line length
	  var gSize = g.append("g")
		  .attr("class", "g-key-size")
		  .attr("transform", "translate(655,-7)");

	  //circle sizes and text in chart key
	  var gSizeInstance = gSize.selectAll("g")
		  .data([{"risk":"low", "size":20e9}, {"risk":"medium", "size":100e9}, {"risk":"high", "size":keyMaxSize}])
		.enter().append("g")
		  .attr("class", "g-system");
		
	  gSizeInstance.append("circle")
		  .style("fill", "#FAFFFF")
		  .attr("r", function(d) { return r(d.size);});

	  gSizeInstance.append("text")
		  .attr("x", function(d) {return r(d.size) + 4; })
		  .attr("dy", ".35em")
		  .text(function(d) { return d.risk;});

	  var gSizeX = 0;

	  gSizeInstance.attr("transform", function() {
		var t = "translate(" + gSizeX + ",10)";
		gSizeX += this.getBBox().width + 25;
		return t;
	  });

	  var gSizeText = g.append("text")
		  .attr("x", 635)
		  .attr("y", 6.5)
		  .style("text-anchor", "end");

	  gSizeText.append("tspan")
		  .style("font-weight", "bold")
		  .text("Size");

	  gSizeText.append("tspan")
		  .style("fill", "#777")
		  .text(" shows risk level");
	}
	
	function controlForce(entry, i) {
	  var nodes = entry.values;

	  var force = d3.layout.force()
		  .nodes(nodes) //should add px and py
		  .size([x.rangeBand(), height])
		  .gravity(.3)
		  .charge(0)
		  .on("tick", controlTick)
		  .start();
		
		//console.log(nodes);
	  var graph_x = isNaN(x0(nodes[0].rate)) ? width - 25 : x0(nodes[0].rate); //placing circles at percentage value
	  var controlCircles = systemControl.append("g")
		  .attr("id", nodes[0].rate.toString().replace(".", ""))
		  .attr("transform", function(d) {return "translate(" + graph_x + ", -150)"})
		.selectAll("circle")
		  .data(nodes)
		.enter().append("circle")
		  .attr("r", function(d) {d.radius = r0(d.impact) * 10; return d.radius;})
		  .attr("id", function(d) { return d.shortName.replace(" ", "__")})
		  .style("fill", function(d) { return d.color})
		  .style("stroke", function(d) { return "#777"})
		  .style("cursor", "pointer")
		  .call(force.drag)
		  .on("mouseover", mouseover)
		  .on("mouseout", mouseout)
		  .on("click", showControls);


		function controlTick() {
			if(systemControl.selectAll("circle")[0].length == new_nodes.length)
				setTimeout(function(){force.stop();}, 1200);
				
			controlCircles
			.each(collide(.7, nodes))
			.attr("cx", function(d) { return d.x})
			.attr("cy", function(d) { return d.y});
		}

	}
	
	// Resolves collisions between d and all other circles.
	function collide(alpha, nodes) {
		var quadtree = d3.geom.quadtree(nodes);
		return function(d) {
		  var r = d.radius + maxRadius + padding,
			  nx1 = d.x - r,
			  nx2 = d.x + r,
			  ny1 = d.y - r,
			  ny2 = d.y + r;
		  quadtree.visit(function(quad, x1, y1, x2, y2) {
			if (quad.point && (quad.point !== d)) {
			  var x = d.x - quad.point.x,
				  y = d.y - quad.point.y,
				  l = Math.sqrt(x * x + y * y),
				  r = d.radius + quad.point.radius + padding;
			  if (l < r) {
				l = (l - r) / l * alpha;
				d.x -= x *= l;
				d.y -= y *= l;
				quad.point.x += x;
				quad.point.y += y;
			  }
			}
			return x1 > nx2 || x2 < nx1 || y1 > ny2 || y2 < ny1;
		  });
		};
	}	

  function mouseoverAnnotation(re) {
    var matches = systemControl.filter(function(d) { return re.test(d.name) || re.test(d.alias); }).classed("g-active", true);
    if (d3.sum(matches, function(d) { return d.length; }) === 1) mouseover(matches.datum());
    else tip.style("display", "none");
  }
	
	function mouseover(d) {
		systemControl.filter(function(c) { return c === d; }).classed("g-active", true);
		//console.log(d);
		var dx = x0(d.rate), dy = d.y, dr = d.radius;
		dy -= 244, dx += 140; // margin fudge factors

		tip.style("display", null)
			.style("top", dy + "px")
			.style("left", dx + "px");

		tip.select(".g-tip-title")
			.text(d.shortName || d.name);

		tipMetric.select(".g-tip-metric-value").text(function(name) {
		  switch (name) {
			case "score": return isNaN(d.rate) ? "N.A." : formatPercent(d.rate);
			case "tests": return d.total;
			case "pass": return d.passes;
			case "fail": return d.fails;
		  }
		});
	}

	function mouseout() {
		tip.style("display", "none");
		systemControl.filter(".g-active").classed("g-active", false);
	}	
	
	function yAxisWrap(g) {
	  g.selectAll(".tick text")
		.filter(function(d) { return /[ ]/.test(d) && this.getComputedTextLength() > margin.left - tickExtension - 10; })
		  .attr("dy", null)
		  .each(function(d) {
			d3.select(this).text(null).selectAll("tspan")
				.data(d.split(" "))
			  .enter().append("tspan")
				.attr("x", this.getAttribute("x"))
				.attr("dy", function(d, i) { return (i * 1.35 - .35) + "em"; })
				.text(function(d) { return d; });
		  });
	}	
	
	function keyuped() {
		if (d3.event.keyCode === 27) {
		  this.value = "";
		  this.blur();
		}
		search(this.value.trim());
	}

	function search(value) {
		if (value) {
		  var re = new RegExp("\\b" + d3.requote(value), "i");
		  svg.classed("g-searching", true);
		  systemControl.selectAll("g").classed("g-match", function(d) { /*console.log(d);*/ return re.test(d.name) || (d.shortName && re.test(d.shortName)); });
		  var matches = d3.selectAll(".g-match");
		  if (matches[0].length === 1) mouseover(matches.datum());
		  else mouseout();
		  searchClear.style("display", null);
		} else {
		  mouseout();
		  svg.classed("g-searching", false);
		  systemControl.classed("g-match", false);
		  searchClear.style("display", "none");
		}
	}
}

function showControls(d){
	location.href="system.html?view=" + d.shortName;
}