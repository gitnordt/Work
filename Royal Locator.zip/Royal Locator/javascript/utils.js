
var royals = ["Prince Nigel", "King Edward", "Princess Ava", "Duchess Madelyn", "Countess Abigayle", "Duke Roderick"];

var routes = {"prince" : {"home": "denwillow_palace"}, 
			  "king" : {"home" : "bagore_palace", 
						"routes":{
							0:["altendorf_court", "altendorf_border_station"],
							1:["altendorf_border_station", "tikrit_bank", "tikrit_cathedral"],
							2:["sturmfeste_bank", "fabric_market", "tikrit_cathedral"],
							3:["altendorf_court", "tikrit_bank", "food_market"],
							4:["altendorf_border_station", "school_of_roggenburg"]
						}}, 
			  "duke" : {"home": "home_of_roderick", 
						"routes":{
							0:["altendorf_border_station", "food_market"],
							1:["sturmfeste_bank", "kireet_cathedral", "denwillow_palace"],
							2:["altendorf_border_station", "tikrit_bank", "tikrit_cathedral"],
							3:["school_of_roggenburg", "sturmfeste_bank", "the_chateau"],
							4:["sturmfeste_bank", "fabric_market"],
							5:["school_of_roggenburg", "tikrit_cathedral", "food_market"]
						}}, 
			  "duchess" : {"home": "home_of_madelyn", 
						"routes":{
							0:["bagore_palace", "altendorf_court"],
							1:["home_of_roderick", "school_of_roggenburg"],
							2:["tikrit_bank", "tikrit_cathedral", "food_market"],
							3:["school_of_roggenburg", "sturmfeste_bank", "the_chateau"],
							4:["sturmfeste_bank", "fabric_market"],
							5:["school_of_roggenburg", "tikrit_cathedral", "food_market"]
						}}, 
			  "countess" : {"home": "home_of_abigayle", 
						"routes":{
							0:["tikrit_bank", "tikrit_cathedral"],
							1:["school_of_roggenburg", "tikrit_cathedral"],
							2:["school_of_roggenburg", "sturmfeste_bank", "the_chateau"],
							3:["sturmfeste_bank", "fabric_market", "the_chateau"],
							4:["school_of_roggenburg", "food_market"]
						}}, 
			  "princess" : {"routes":{
							0:["tikrit_bank", "tikrit_cathedral"],
							1:["school_of_roggenburg", "tikrit_cathedral"],
							2:["school_of_roggenburg", "sturmfeste_bank", "the_chateau"],
							3:["sturmfeste_bank", "fabric_market", "the_chateau"],
							4:["school_of_roggenburg", "food_market"]
						}}, 
			 };

//var routes = {"prince" : ["home": "denwillow_palace", "routes":{"altendorf_court", "altendorf_border_station"}], "king" : "bagore_palace", "duchess" : "home_of_madelyn", 
		
			
var places = ["Tikrit Cathedral", "Kireet Cathedral", "The Chateau", "School of Roggenburg", "School of Hoverland", 
			"Bagore Palace", "Denwillow Palace", "Food Market", "Farmer's Market", "Fabric Market", "Dress Tower", 
			"Altendorf Court", "Denwillow Court", "Altendorf Border Station", "Sudsmanor Border Station", "Tikrit Bank", 
			"Sturmfeste Bank", "Kireet Bank", "Duchess Madelyn's Home", "Countess Abigayle's Home", "Duke Roderick's Home"]

var countries = {"kireet" : {"cities" : ["sudsmanor", "denbrook", "denwillow", "hoverland"], "borders" : ["kireet_border", "tikrit_border"]}, 
			"tikrit" : {"cities" : ["bagore", "ferenbach", "dietzenfeld", "altendorf", "roggenburg"], "borders" : ["tikrit_border", "sturmfeste_border"]}, 
			"sturmfeste":{"cities" : ["wetterfort", "belseburg", "schensfeld"], "borders" : ["sturmfeste_border", "kireet_border"]}};




function toCamelCase(str) {
	return str.replace(/(?:^|\s)\w/g, function(match) {
	  return match.toUpperCase();
	});
}