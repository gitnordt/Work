var parse_text_p = function(text, tag) {
	return text;
};
