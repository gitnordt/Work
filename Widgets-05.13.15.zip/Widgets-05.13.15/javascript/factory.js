
document.writeln('<script language="javascript" type="text/javascript" src="./javascript/html2canvas.js"></script>');
document.writeln('<script language="javascript" type="text/javascript" src="./javascript/jquery.plugin.html2canvas.js"></script>');

var haslocalStorage = checkLocalStorage();
var classification = "UNCLASSIFIED/FOUO";

function getHeader(){
	return "<br><h1>" + classification + "</h1><br><br>";
}

function getFooter(data_type){
	var footer = "<br><br><h1><span style='color:red;'>WARNING:</span> This data is unofficial and should only be used for analytic purposes.</h1>";
	
	if(data_type == "uac")
		footer += "<h1><span style='font-weight:bold; text-decoration: underline;'>Note:</span> <span style='font-style: italic;'>The information displayed represents data collected from January 01, 2014 through October 15, 2014</span></h1>";
	else if(data_type == "nb")
		footer += "<h1><span style='font-weight:bold; text-decoration: underline;'>Note:</span> <span style='font-style: italic;'>The information displayed represents data collected from January 2009 through December 2011</span></h1>";
	else
		footer += "<h1><span style='font-weight:bold; text-decoration: underline;'>Note:</span> <span style='font-style: italic;'>The information displayed represents data collected from January 2004 through December 2014</span></h1>";

	footer += "<br><h1>" + classification + "</h1>";

	return footer;
}
	
function createDataSet (object, object_id, field_objects, widget_type, object_idx){
	//remove duplicate countries
	var uniqueobjects = object.unique();
	var datasets = {};

	for (var o = 0; o < uniqueobjects.length; o++) {
		 var previous = "";
		 var uniquevalues = [];
		 var uniquecounts = [];
	
		 if (uniqueobjects[o] != '' && typeof uniqueobjects[o] != 'undefined') {
			  var name = uniqueobjects[o];
			  // Find data for each unique country name
			  var counter = 0;
			  var allvalues = [];
	   
			 if(widget_type == "days"){
				for (var d = 0; d < field_objects.length; d++) {
					var field = field_objects[d];
					var date  = new Date(field.date);
					if (field[object_id] == name) {
						allvalues[counter] = date.getDay();
						counter++;		
					}		
				} 
			  }
			  else if(widget_type == "dates"){
				for (var d = 0; d < field_objects.length; d++) {
					var field = field_objects[d];
					if (field[object_id] == name) {
						allvalues[counter] = field.date;
						counter++;		
					}		
				} 
			  }
			  else if(widget_type == "months"){
				for (var d = 0; d < field_objects.length; d++) {
					var field = field_objects[d];
					var date = validateDate(field.date, false, true).replace('/', '/01/');
					if (field[object_id] == name) {
						allvalues[counter] = date;
						counter++;		
					}		
				} 
			  }
			  else if(widget_type == "age"){
				  for (var d = 0; d < field_objects.length; d++) {
						var field = field_objects[d];
						if (field[object_id] == name) {
							allvalues[counter] = field.age;
							counter++;		
						}	
				  } 		  
			  }
			  else if(widget_type == "years"){
				var year_cnt = 0;
				for (var d = 0; d < field_objects.length; d++) {
					var field = field_objects[d];
					if (field[object_id] == name) {
						var current = field.date;
						//console.log(field.entries);
						if(uniquecounts.length == 0){
							uniquevalues.push(current);
							uniquecounts[year_cnt] = field.entries;			
						}
						else if (current != previous) {
							uniquevalues.push(current);
							year_cnt++;
							uniquecounts[year_cnt] = field.entries;	
						} else {
							uniquecounts[year_cnt] = parseInt(uniquecounts[year_cnt]) + parseInt(field.entries);		
						}
						previous = current;
					}	
				} 										
			  }
			  else if(widget_type == "weight"){
				var weight_cnt = 0;
				for (var d = 0; d < field_objects.length; d++) {
					var field = field_objects[d];
					if (field[object_id] == name) {
						var current = field.date;
						//console.log(field.weight);
						if(uniquecounts.length == 0){
							uniquevalues.push(current);
							uniquecounts[weight_cnt] = field.weight;			
						}
						else if (current != previous) {
							uniquevalues.push(current);
							weight_cnt++;
							uniquecounts[weight_cnt] = field.weight;	
						} else {
							uniquecounts[weight_cnt] = parseFloat(uniquecounts[weight_cnt]) + parseFloat(field.weight);		
						}
						previous = current;
					}	
				} 										
			  }
			  else if(widget_type == "ports"){
				var weight_cnt = 0;
				for (var d = 0; d < field_objects.length; d++) {
					var field = field_objects[d];
					if (field[object_id] == name) {
						var current = null;		
						//console.log(field.weight);
						$.each(object_idx, function(key, value){
							if(field.port == value[1]){
								current = value[0];
								return false;
							}
						});					
						if(uniquecounts.length == 0){
							uniquevalues.push(current);
							uniquecounts[weight_cnt] = field.weight;			
						}
						else if (current != previous && !in_array(current, uniquevalues)) {
							uniquevalues.push(current);
							weight_cnt++;
							uniquecounts[weight_cnt] = field.weight;	
						} else {
							uniquecounts[weight_cnt] = parseFloat(uniquecounts[weight_cnt]) + parseFloat(field.weight);	
						}
						previous = current;
					}	
				} 										
			  }		  

			  // Sort data and count occurrences
			  if(widget_type != "years" && widget_type != "weight"){
				 // Sort country data and counter occurrences for each day
					if(widget_type != "dates" && widget_type != "months")
						allvalues.sort();

					for (var i = 0; i < allvalues.length; i++) {
						var current = allvalues[i];
						if(i == 0 || current != previous){
							uniquevalues.push(current);
							uniquecounts.push(1);			
						}
						else 
							uniquecounts[uniquecounts.length-1]++;		
					
						previous = current;
					}
			  }		  
			
			  // Form data values string for graph
			  var datastring = "[";
			  if(haslocalStorage) localStorage.setItem("datastring", datastring);
			  for (var i = 0; i < uniquevalues.length; i++) {
				   if(widget_type == "dates" || widget_type == "years" || widget_type == "weight" || widget_type == "months")
						datastring += "[" + (Date.parse(uniquevalues[i])) + ", " + uniquecounts[i] + "]";
				   else
						datastring += "[" + uniquevalues[i] + ", " + uniquecounts[i] + "]";
						
				   if (i == uniquevalues.length - 1) {
						datastring += "";
						if(haslocalStorage) localStorage.setItem("datastring", datastring);
				   } 
				   else {
						datastring += ", ";
						if(haslocalStorage) localStorage.setItem("datastring", datastring);
				   }
			  }
			
			  datastring += "]";
			  //console.log(datastring);

			  if(haslocalStorage) localStorage.setItem("datastring", datastring);

			  var graphvalues  = "";
			  if(widget_type != "years" && widget_type != "weight" && widget_type != "ports"){
				  if(haslocalStorage) 
					graphvalues = eval(localStorage.getItem("datastring"));
				  else 
					graphvalues = eval(datastring);
			  }
			  else{
				  if(haslocalStorage)
					graphvalues = eval(localStorage.getItem("datastring")).sort(sortByProperty(0));
				  else 
					graphvalues = eval(datastring).sort(sortByProperty(0));
			  }

			  //calculate the entry total for each country/port
			  var entry_cnt = 0;
			  if(widget_type == "ports" || widget_type == "weight"){
				for (var k = 0; k < graphvalues.length; k++){
					entry_cnt = graphvalues[k][1] + entry_cnt;
				}
				if(entry_cnt == 0)
						entry_cnt = entry_cnt.toFixed(2);
			  }
			  else{
				for (var k = 0; k < graphvalues.length; k++)
					entry_cnt = parseInt(graphvalues[k][1]) + parseInt(entry_cnt);
			  }

			  var objToAdd = {};
			  // Graph values
			  if(widget_type == "ports" || widget_type == "weight")
				entry_cnt = parseFloat(entry_cnt).toFixed(2);
				
			  if(widget_type == "days" || widget_type == "ports"){
				  objToAdd = {
					label: name,
					total: entry_cnt,
					data: graphvalues,
					bars: {
						show: true,
						barWidth: .15,
						fill: true,
						lineWidth: 2,
						order: o
					},
					color: o //color index
				  };
			  }
			  else{
				  objToAdd = {
					label: name,
					total: entry_cnt,
					data: graphvalues,
					color: o //color index
				  };	  
			  }

			  if(parseFloat(entry_cnt) != 0)
				datasets[name] = objToAdd;
		 }
	}
	//sort
	datasets = objectPropertySort(datasets, "total");

	return datasets;
}

function sortChart(datasets){
	var idx = 0;
	$.map(datasets, function(value, key) {
		value.bars.order = idx;
		idx++;
	});
}

// Show the tooltip
function showTooltip(x, y, contents) {
	$('<div id="tooltip">' + contents + '</div>').css( {
		position: 'absolute',
		display: 'inline',
		"z-index": 100,
		top: y - 35,
		left: x + 5,
		border: '1px solid #fdd',
		padding: '2px',
		'background-color': '#fee',
		opacity: 1.0
	}).appendTo("body").fadeIn(200);
}

//Update graph based on filtered and unfiltered data
function plotAccordingToChoices(choiceContainer, datasets, options) {
	var data = [];
	var plot = null;
	
	choiceContainer.find("input:checked").each(function () {
		var key = $(this).attr("name");
		if (key && datasets[key])
			data.push(datasets[key]);
	});

	if (data.length > 0){
		$("#placeholder").text(""); 
		plot = $.plot($("#placeholder"), data, options);
	}
	else
		$("#placeholder").text("No Data Available"); 
		
	return plot;
}

function getTotalCount (choice){
	var id = choice.attr("id");
	var label = $("label[for='"+id.replace(/'/g, "\\'")+"']").text();
	var total = label.split(')');
	var format_cnt = total[0].replace('(','');
	return format_cnt;
}

function reverseChoices(choiceContainer){
	var choices = choiceContainer.children();
	choiceContainer.empty();
	//reverse choices in the choiceContainer
	choiceContainer.append(choices.get().reverse());
	choiceContainer.children('input').each(function() {
		$(this).insertBefore($(this).prev('label'));
	});
}

function setPresetChecks(datasets, orderBy){
	var preset_checks = [{"location":"", "activity": 0},{"location":"", "activity": 0},{"location":"", "activity": 0}];

	if(orderBy == "totals"){
		$.each(datasets, function(key, val) {
			//Set the cities with the most activity
			if(val.total > preset_checks[2].activity && val.total > preset_checks[1].activity && val.total > preset_checks[0].activity){
				preset_checks[2] = preset_checks[1];
				preset_checks[1] = preset_checks[0];
				preset_checks[0] = {"location":val.label, "activity": val.total};
			}
			else if(val.total > preset_checks[2].activity && val.total > preset_checks[1].activity){
				preset_checks[2] = preset_checks[1];
				preset_checks[1] = {"location":val.label, "activity": val.total};
			}
			else if(val.total > preset_checks[2].activity){
				preset_checks[2] = {"location":val.label, "activity": val.total};
			}
		});
	}
	else if(orderBy == "countries"){
		$.each(datasets, function(key, val) {
			//honduras, guatemala, el salvador
			if(val.label.toLowerCase() == "el salvador" || val.label.toLowerCase() == "el savador")
				preset_checks[0] = {"location":val.label, "activity": val.total};
			else if(val.label.toLowerCase() == "guatemala")
				preset_checks[1] = {"location":val.label, "activity": val.total};
			else if(val.label.toLowerCase() == "honduras")
				preset_checks[2] = {"location":val.label, "activity": val.total};
		});
	}	
	else if(orderBy == "apprehensions"){
		$.each(datasets, function(key, val) {
			//honduras, guatemala, el salvador
			if(val.label.toLowerCase() == "central america")
				preset_checks[0] = {"location":val.label, "activity": val.total};
			else if(val.label.toLowerCase() == "mexico")
				preset_checks[1] = {"location":val.label, "activity": val.total};
		});
	}
	
	return preset_checks;
 
}

function selectPresetChecks(datasets, preset_checks, choiceContainer, keycount, widget_type){
	var counter = 0;
	$.each(datasets, function(key, val) {
		var select = false;
		//get the countries with the most activity and set its checkbox to checked
		for (var i = 0; i < preset_checks.length; i++) {
			if(preset_checks[i].location == val.label){
				select = true;
				break;
			}
		}
		
		var total = val.total;
		//if(widget_type == "ports")
		//	total = total.toFixed(2);

		
		if(select)
			choiceContainer.append('<input type="checkbox" name="' + key + '" checked="checked" id="id' + key + '">'
								  + '<label for="id' + key + '">' + "(" + total + ") " + val.label + '</label>');    
		else
			choiceContainer.append('<input type="checkbox" name="' + key + '" id="id' + key + '">'
								  + '<label for="id' + key + '">' + "(" + total + ") " + val.label + '</label>');    
		
		if(counter < keycount - 1)
			choiceContainer.append('<br/>');
		
		counter ++;
	});
}

function getReportPrefix(tab_name){
	var prefix = "";
	
	if(tab_name.toLowerCase().indexOf("sector") != -1){
		if($('#' + tab_name).hasClass("selected") == true)
			prefix = "Sector";
		else
			prefix = "Country";
	}
	
	if(tab_name.toLowerCase().indexOf("dates") != -1){
		if($('#' + tab_name).hasClass("selected") == true)
			prefix = "Date";
		else
			prefix = "Month";
	}
	
	if(tab_name.toLowerCase().indexOf("port") != -1){
		if($('#' + tab_name).hasClass("selected") == true)
			prefix = "Port";
		else
			prefix = "Sector";
	}
	
		
	return prefix;
}

function exportData(datasets, report_title, headers, type, conversion){
	//Set Report title in first row or line
	var CSV = report_title + '\r\n\n';
	var row = "";
	
	var obj_keys = $.map(datasets, function(value, key) {
			return key;
	});
	
	$.each(datasets[obj_keys[0]], function(key, val) {
		if(typeof(val) != "function" && key != "color" && key != "data" && key != "bars")
			row += key.toUpperCase() + ',';
		else if(key == "data")
			row += headers;
	});
	
	//remove last comma and append Label row with line break
	row = row.slice(0, -1);
	CSV += row + '\r\n';

	//set data for each row of the file
	$.each(datasets, function(key, set) {
		var row = "";
		var tmp_row = "";
		$.each(set, function(data_key, value) {
			if(typeof(value) != "function" && data_key != "color" && data_key != "data" && data_key != "bars")
				tmp_row += '"' + value + '",';
			else if(data_key == "data"){
				for (var index in value){
					if(typeof(value[index]) != "function"){
						if(type == "days")
							row = tmp_row + '"' + dayNames[value[index][0]] + '",' + '"' + value[index][1] + '",';
						else if(type == "dates")
							row = tmp_row + '"' + validateDate(value[index][0], true, true) + '",' + '"' + value[index][1] + '",';
						else if(type == "ports")
							row = tmp_row + '"' + conversion[parseInt(value[index][0]) + 1] + '",' + '"' + value[index][1] + '",';
						else if(type == "months")
							row = tmp_row + '"' + validateDate(value[index][0], false, true) + '",' + '"' + value[index][1] + '",';
						else
							row = tmp_row + '"' + value[index][0] + '",' + '"' + value[index][1] + '",';
							
						row = row.slice(0, row.length - 1);
						CSV += row + '\r\n';
					}
				}
			}
		});
	});

	if (CSV == '') {        
		alert("Invalid data");
		return;
	}   
	
	//console.log(CSV);
	//Generate a file name
	var fileName = "Report_";
	//this will remove the blank-spaces from the title and replace it with an underscore
	fileName += report_title.replace(/-/g,"_").replace(/ /g,"");   

	//Initialize file anchor
	var link = document.createElement("a"); 
	link.id = "exportLink";
	link.style.visibility = "hidden";
	
	if (!isIEBrowser())
	{
		var uri = 'data:text/csv;charset=utf-8,' + escape(CSV);
		link.href = uri;
		link.download = fileName + ".csv";
		//anchor tag and remove it after automatic click
		document.body.appendChild(link);
		link.click();
		document.body.removeChild(link);
	}
	else if(navigator.msSaveBlob){
	
		var blob = new Blob([escape(CSV)], {
		  "type": "text/csv;charset=utf8;"			
		});
		
		link.setAttribute("href", "#");
		link.addEventListener("click", function(event) {
			navigator.msSaveBlob(blob, fileName + ".csv");
		}, false);
	}
	else
	{
		alert("This browser does not support the export operation for CSV files. The file will be downloaded as a text file.");
		ieFrame.document.open("text/html", "replace");
		ieFrame.document.charset = "utf-8";
		ieFrame.document.write("<PRE>" + CSV + "</PRE>");
		ieFrame.document.close();
		ieFrame.focus();
		ieFrame.document.execCommand('SaveAs', true, fileName + '.txt');
	}   

}

function exportImage(report_title, data_type){
	var fileName = "Img_";
	//this will remove the blank-spaces from the title and replace it with an underscore
	fileName += report_title.replace(/-/g,"_").replace(/ /g,"");  
	var chartImage = null;
			
	html2canvas($("#exterior_canvas"), {
		onrendered: function(canvas) {
			chartImage = canvas.toDataURL("image/png");
			var w=window.open('about:blank');
			var header = getHeader();
			var footer = getFooter(data_type);

			w.document.write("<link rel='stylesheet' href='./css/widgets_style.css' type='text/css'/><center>" + header + "<img src='"+ chartImage +"' alt='"+ fileName + "'/>"  + footer + "</center>");		
		}
	});
}

function getOriginalPoint(item){
	var originalPoint;
	if (item.datapoint[0] == item.series.data[0][3]) {
		originalPoint = item.series.data[0][0];
	} else if (item.datapoint[0] == item.series.data[1][3]){
		originalPoint = item.series.data[1][0];
	} else if (item.datapoint[0] == item.series.data[2][3]){
		originalPoint = item.series.data[2][0];
	} else if (item.datapoint[0] == item.series.data[3][3]){
		originalPoint = item.series.data[3][0];
	} else if (item.datapoint[0] == item.series.data[4][3]){
		originalPoint = item.series.data[4][0];
	} else if (item.datapoint[0] == item.series.data[5][3]){
		originalPoint = item.series.data[5][0];
	} else if (item.datapoint[0] == item.series.data[6][3]){
		originalPoint = item.series.data[6][0];
	}

	return originalPoint;
}